package life.league.challenge.kotlin.app.ui.photo

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import life.league.challenge.kotlin.app.injectables.AppRepository
import life.league.challenge.kotlin.app.ui.Status

class PhotoActivityViewModel(
        private val appRepository: AppRepository) : ViewModel() {

    private val _viewState: MutableLiveData<PhotoActivityViewState> = MutableLiveData()
    val viewState: LiveData<PhotoActivityViewState> get() = _viewState

    fun loadFirstAlbumImage(albumId: String) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                val wrapper = appRepository.getPhotos(albumId)
                when (wrapper.status) {
                    Status.SUCCESS -> {
                        val photos = wrapper.data
                        if (photos == null) {
                            _viewState.postValue(PhotoActivityViewState.Error("Server call was successful but user data was null"))
                        } else {
                            _viewState.postValue(PhotoActivityViewState.Ready(photos[0]))
                        }
                    }
                    Status.ERROR -> _viewState.postValue(PhotoActivityViewState.Error(wrapper.errorMsg))
                }

            }
        }
    }
}