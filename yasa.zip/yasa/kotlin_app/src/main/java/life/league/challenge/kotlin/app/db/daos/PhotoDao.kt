package life.league.challenge.kotlin.app.db.daos

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import life.league.challenge.kotlin.app.db.entities.Album
import life.league.challenge.kotlin.app.db.entities.Photo


@Dao
interface PhotoDao {
    @Query("SELECT * from photos WHERE id IN (:albumIds)")
    suspend fun getPhotosByAlbumId(albumIds: String): List<Photo>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPhotos(photos: List<Photo>)

    @Query("DELETE FROM photos")
    suspend fun truncate()
}
