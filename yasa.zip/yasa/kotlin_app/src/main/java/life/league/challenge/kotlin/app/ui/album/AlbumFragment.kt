package life.league.challenge.kotlin.app.ui.album

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ProgressBar
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import life.league.challenge.kotlin.R
import life.league.challenge.kotlin.app.ui.ViewModelFactory
import life.league.challenge.kotlin.app.ui.album.models.UserAlbum
import life.league.challenge.kotlin.app.ui.photo.PhotoActivity

class AlbumFragment: Fragment(), AlbumAdapter.IAlbumClickListener {

    companion object {
        val TAG: String = AlbumFragment::class.java.simpleName
        val BUNDLE_USERID = "BUNDLE_USERID"

        fun newInstance(userId: String) = AlbumFragment().apply {
            arguments = Bundle().apply {
                putString(BUNDLE_USERID, userId)
            }
        }
    }

    private lateinit var loadingIndicator: ProgressBar
    private lateinit var errorMsg: TextView
    private lateinit var albumList: RecyclerView
    private lateinit var viewModel: AlbumFragmentViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        context?.let { ctx ->
            viewModel = ViewModelProvider(this, ViewModelFactory(ctx)).get(AlbumFragmentViewModel::class.java)
            viewModel.viewState.observe(this, Observer { state -> updateViewState(state) })
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.fragment_album, container, false)
        albumList = view.findViewById(R.id.album_list)
        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        loadingIndicator = view.findViewById(R.id.loading_indicator)
        errorMsg = view.findViewById(R.id.error)
        albumList = view.findViewById(R.id.album_list)
        albumList.layoutManager = GridLayoutManager(view.context, 3)

        arguments?.getString(BUNDLE_USERID)?.let { userId ->
            viewModel.loadAlbums(userId)
        }
    }

    private fun updateViewState(state: AlbumFragmentViewState?) {
        when(state) {
            AlbumFragmentViewState.Loading -> {
                loadingIndicator.visibility = View.VISIBLE
                errorMsg.visibility = View.GONE
                albumList.visibility = View.GONE
            }
            is AlbumFragmentViewState.Error -> {
                loadingIndicator.visibility = View.GONE
                errorMsg.visibility = View.VISIBLE
                albumList.visibility = View.GONE

                errorMsg.text = state.errorMsg
            }
            is AlbumFragmentViewState.Ready -> {
                loadingIndicator.visibility = View.GONE
                errorMsg.visibility = View.GONE
                albumList.visibility = View.VISIBLE
                loadAlbumList(state.albums)
            }
        }
    }

    private fun loadAlbumList(albums: ArrayList<UserAlbum>) {
        albumList.adapter = AlbumAdapter(albums, this)
    }

    override fun onAlbumClicked(userAlbum: UserAlbum) {
        activity?.let { parentActivity ->
            val intent = Intent(parentActivity, PhotoActivity::class.java)
            intent.putExtra(PhotoActivity.BUNDLE_ALBUMID, userAlbum.id)
            parentActivity.startActivity(intent)
        }
    }
}
