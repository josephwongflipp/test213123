package life.league.challenge.kotlin.app.ui.main

import android.os.Bundle
import android.view.View
import android.widget.ProgressBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import life.league.challenge.kotlin.R
import life.league.challenge.kotlin.app.ui.ViewModelFactory
import life.league.challenge.kotlin.app.ui.main.models.UserPost

class MainActivity : AppCompatActivity(), PostAdapter.IPostAdapterClickListener {

    private lateinit var viewModel: MainActivityViewModel
    private lateinit var toolbar: Toolbar
    private lateinit var loadingIndicator: ProgressBar
    private lateinit var recyclerView: RecyclerView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)
        toolbar.title = "YASA"

        loadingIndicator = findViewById(R.id.loading_indicator)
        recyclerView = findViewById(R.id.post_list)
        recyclerView.layoutManager = LinearLayoutManager(this)

        viewModel = ViewModelProvider(this, ViewModelFactory(this)).get(MainActivityViewModel::class.java)
        viewModel.viewState.observe(this, Observer { state -> updateViewState(state) })

        // Kickoff the whole process of getting data
        viewModel.loginAndFetchPosts("joseph", "password")
    }

    private fun updateViewState(state: MainActivityViewState) {
        when (state) {
            MainActivityViewState.Loading -> {
                loadingIndicator.visibility = View.VISIBLE
                recyclerView.visibility = View.GONE
            }
            is MainActivityViewState.Error -> {
                Toast.makeText(this, state.errorMsg, Toast.LENGTH_SHORT).show()
            }
            is MainActivityViewState.Ready -> {
                loadingIndicator.visibility = View.GONE
                recyclerView.visibility = View.VISIBLE
                val adapter = PostAdapter(state.userPosts, this)
                recyclerView.adapter = adapter
            }
        }
    }

    override fun onPostClicked(userPost: UserPost) {
        viewModel.navigateToProfile(this, userPost.userId)
    }
}
