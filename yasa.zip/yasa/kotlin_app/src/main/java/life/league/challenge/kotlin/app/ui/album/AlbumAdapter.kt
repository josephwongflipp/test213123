package life.league.challenge.kotlin.app.ui.album

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import life.league.challenge.kotlin.R
import life.league.challenge.kotlin.app.ui.album.models.UserAlbum
import life.league.challenge.kotlin.app.ui.common.SquareRelativeLayout

class AlbumAdapter(
        val albums: ArrayList<UserAlbum>,
        val clickListener: IAlbumClickListener)
    : RecyclerView.Adapter<AlbumAdapter.AlbumViewHolder>() {

    interface IAlbumClickListener {
        fun onAlbumClicked(userAlbum: UserAlbum)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AlbumViewHolder {
        return AlbumViewHolder(LayoutInflater.from(parent.context).inflate(R.layout.item_album, parent, false))
    }

    override fun getItemCount(): Int {
        return albums.size
    }

    override fun onBindViewHolder(holder: AlbumViewHolder, position: Int) {

        val userAlbum: UserAlbum = albums[position]

        holder.title.text = userAlbum.title
        holder.container.setOnClickListener { clickListener.onAlbumClicked(userAlbum) }
        // TODO: do something fancy with the thumbnail later.
    }

    class AlbumViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val container: SquareRelativeLayout = view.findViewById(R.id.container)
        val thumbnail: ImageView = view.findViewById(R.id.thumbnail)
        val title: TextView = view.findViewById(R.id.title)
    }
}
