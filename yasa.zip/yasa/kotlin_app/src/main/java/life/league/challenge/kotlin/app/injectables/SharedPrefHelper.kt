package life.league.challenge.kotlin.app.injectables

import android.content.Context

/**
 * Manages all CRUD operations regarding our SharedPreferences.
 */
class SharedPrefHelper(val context: Context) {
    companion object {
        private const val PREFERENCE_KEY = "com.example.spkey"
        const val API_KEY = "API_KEY"
    }

    private val sharedPref = context.getSharedPreferences(PREFERENCE_KEY, Context.MODE_PRIVATE)

    fun saveApiKey(key: String) {
        sharedPref.edit().putString(API_KEY, key).apply()
    }

    fun getApiKey(): String? {
        return sharedPref.getString(API_KEY, null)
    }
}
