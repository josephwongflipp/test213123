package life.league.challenge.kotlin.app.ui.photo

import android.os.Bundle
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.bumptech.glide.Glide
import com.bumptech.glide.load.model.GlideUrl
import com.bumptech.glide.load.model.LazyHeaders
import com.bumptech.glide.request.RequestOptions
import life.league.challenge.kotlin.R
import life.league.challenge.kotlin.app.ui.ViewModelFactory

class PhotoActivity : AppCompatActivity(), View.OnClickListener {

    companion object {
        val BUNDLE_ALBUMID = "BUNDLE_ALBUMID"
    }

    private lateinit var container: FrameLayout
    private lateinit var photo: ImageView
    private lateinit var error: TextView
    private lateinit var viewModel: PhotoActivityViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_photo)

        val albumId = intent.extras?.getString(BUNDLE_ALBUMID)

        container = findViewById(R.id.container)
        container.setOnClickListener(this)
        photo = findViewById(R.id.photo)
        error = findViewById(R.id.error)

        viewModel = ViewModelProvider(this, ViewModelFactory(this)).get(PhotoActivityViewModel::class.java)
        viewModel.viewState.observe(this, Observer { state -> updateViewState(state) })
        viewModel.loadFirstAlbumImage(albumId!!)
    }

    private fun updateViewState(state: PhotoActivityViewState?) {
        when (state) {
            PhotoActivityViewState.Loading -> {} // TODO
            is PhotoActivityViewState.Error -> {
                error.text = state.errorMsg
            }
            is PhotoActivityViewState.Ready -> {

                // IMPORTANT!!!!!
                // Looks like via.placeholder.com is blocking requests from anything with a Dalvik UA
                // Source: https://github.com/bumptech/glide/issues/4074
                // As a workaround I'm going to fake our UA header just to get the image to load.
                // IMPORTANT!!!!!

                val glideUrl = GlideUrl(
                        state.userAlbumPhoto.url,
                        LazyHeaders.Builder()
                                .addHeader("User-Agent", "User-Agent: WebKit/2.1.0 (Linux; U; Android 10; Pixel 3 XL Build/QP1A.191005.007)")
                                .build())

                val options = RequestOptions().fitCenter()
                Glide.with(this)
                        .load(glideUrl)
                        .apply(options)
                        .into(photo)

                error.text = "If you're not seeing an image, it might be because via.placeholder.com is blocking Dalvik UA. Here's the url we're trying to load ${state.userAlbumPhoto.url}"
            }
        }
    }

    override fun onClick(v: View?) {
        when(v?.id) {
            R.id.container -> finish()
        }
    }

}