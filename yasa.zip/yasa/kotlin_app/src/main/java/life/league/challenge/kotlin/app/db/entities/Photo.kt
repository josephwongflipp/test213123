package life.league.challenge.kotlin.app.db.entities

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "photos")
class Photo(
        @PrimaryKey @ColumnInfo(name = "id") val id: String,
        @ColumnInfo(name = "albumId") val albumId: String,
        @ColumnInfo(name = "title") val title: String,
        @ColumnInfo(name = "url") val url: String,
        @ColumnInfo(name = "thumbnailUrl") val thumbnailUrl: String
)
