package life.league.challenge.kotlin.app.injectables

import android.content.Context
import android.net.ConnectivityManager

/**
 * Util class for device-specific state.
 */
class DeviceHelper(private val context: Context) {

    fun hasNetwork(): Boolean {
        var isConnected = false // Initial Value
        val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val activeNetwork = connectivityManager.activeNetworkInfo
        if (activeNetwork != null && activeNetwork.isConnectedOrConnecting) isConnected = true
        return isConnected
    }
}
