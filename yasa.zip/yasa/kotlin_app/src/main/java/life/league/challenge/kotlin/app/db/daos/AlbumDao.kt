package life.league.challenge.kotlin.app.db.daos

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import life.league.challenge.kotlin.app.db.entities.Album
import life.league.challenge.kotlin.app.db.entities.Post

@Dao
interface AlbumDao {
    @Query("SELECT * from albums WHERE userId IN (:userIds)")
    suspend fun getAlbumsByUserIds(userIds: String): List<Album>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAlbums(albums: List<Album>)

    @Query("DELETE FROM albums")
    suspend fun truncate()
}
