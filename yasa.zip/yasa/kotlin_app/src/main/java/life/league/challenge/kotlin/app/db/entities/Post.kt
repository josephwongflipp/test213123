package life.league.challenge.kotlin.app.db.entities

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "posts")
class Post(
        @PrimaryKey @ColumnInfo(name = "id") val id: String,
        @ColumnInfo(name = "userId") val userId: String,
        @ColumnInfo(name = "title") val title: String,
        @ColumnInfo(name = "body") val body: String
)