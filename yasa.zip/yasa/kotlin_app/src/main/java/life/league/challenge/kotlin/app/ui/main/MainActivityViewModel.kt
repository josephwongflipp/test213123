package life.league.challenge.kotlin.app.ui.main

import android.app.Activity
import android.content.Intent
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import life.league.challenge.kotlin.app.injectables.AppRepository
import life.league.challenge.kotlin.app.injectables.DeviceHelper
import life.league.challenge.kotlin.app.ui.Status
import life.league.challenge.kotlin.app.ui.profile.ProfileActivity

class MainActivityViewModel(
        val appRepository: AppRepository,
        val dispatcher: CoroutineDispatcher = Dispatchers.IO) : ViewModel() {

    // View state live data
    private val _viewState: MutableLiveData<MainActivityViewState> = MutableLiveData()
    val viewState: LiveData<MainActivityViewState> get() = _viewState

    /**
     * Attempts to login and fetch posts. If the user has authenticated and pulled data before,
     * get the db-cached data.
     */
    fun loginAndFetchPosts(username: String, password: String) {
        viewModelScope.launch {
            withContext(dispatcher) {
                val wrapper = appRepository.login(username, password)
                when (wrapper.status) {
                    Status.ERROR -> _viewState.postValue(MainActivityViewState.Error(wrapper.errorMsg))
                    Status.SUCCESS -> fetchUserPosts()
                }
            }
        }
    }

    /**
     * Fetches User and Post data from the repository.
     */
    private suspend fun fetchUserPosts() {
        val wrapper = appRepository.getUserPosts()
        when (wrapper.status) {
            Status.SUCCESS -> {
                if (wrapper.data == null) {
                    _viewState.postValue(MainActivityViewState.Error("Successfully got user posts but it was invalid/empty"))
                } else {
                    _viewState.postValue(MainActivityViewState.Ready(wrapper.data))
                }
            }
            Status.ERROR -> _viewState.postValue(MainActivityViewState.Error("Unable to pull user post data, try again later"))
        }
    }

    fun navigateToProfile(activity: Activity, userId: String?) {
        val intent = Intent(activity, ProfileActivity::class.java)
        intent.putExtra(ProfileActivity.BUNDLE_USERID, userId)
        activity.startActivity(intent)
    }
}
