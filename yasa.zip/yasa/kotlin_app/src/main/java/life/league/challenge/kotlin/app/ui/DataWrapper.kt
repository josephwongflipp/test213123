package life.league.challenge.kotlin.app.ui

data class DataWrapper<out T>(
        val status: Status,
        val data: T?,
        val errorMsg: String?
)

enum class Status {
    SUCCESS,
    ERROR
}