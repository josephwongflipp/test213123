package life.league.challenge.kotlin.api

import android.util.Base64
import life.league.challenge.kotlin.app.db.entities.Album
import life.league.challenge.kotlin.app.db.entities.Photo
import life.league.challenge.kotlin.app.db.entities.Post
import life.league.challenge.kotlin.app.db.entities.User
import life.league.challenge.kotlin.model.Account
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class Service {

    private val HOST = "https://engineering.league.dev/challenge/api/"
    private val TAG = "Service"

    private val api: Api by lazy {
        val retrofit = Retrofit.Builder()
                .baseUrl(HOST)
                .addConverterFactory(GsonConverterFactory.create())
                .build()
        retrofit.create<Api>(Api::class.java)
    }

    fun login(username: String, password: String): Account? {
        val credentials = "$username:$password"
        val auth = "Basic " + Base64.encodeToString(credentials.toByteArray(), Base64.NO_WRAP)

        val call = api.login(auth)
        val response = call.execute()

        if (response.isSuccessful) {
            return response.body()
        } else {
            return null
        }
    }

    fun getUsers(apiKey: String): List<User>? {
        val call = api.users(apiKey)
        val response = call.execute()

        if (response.isSuccessful) {
            return response.body()
        } else {
            return null
        }
    }

    fun getPosts(apiKey: String): List<Post>? {
        val call = api.posts(apiKey)
        val response = call.execute()

        if (response.isSuccessful) {
            return response.body()
        } else {
            return null
        }
    }

    fun getAlbums(apiKey: String, userId: String): List<Album>? {
        val call = api.albums(apiKey, userId)
        val response = call.execute()

        if (response.isSuccessful) {
            return response.body()
        } else {
            return null
        }
    }

    fun getPhotos(apiKey: String, albumId: String): List<Photo>? {
        val call = api.photos(apiKey, albumId)
        val response = call.execute()

        if (response.isSuccessful) {
            return response.body()
        } else {
            return null
        }
    }
}
