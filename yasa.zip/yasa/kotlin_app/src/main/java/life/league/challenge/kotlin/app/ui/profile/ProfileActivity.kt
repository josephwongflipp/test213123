package life.league.challenge.kotlin.app.ui.profile

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.bumptech.glide.Glide
import de.hdodenhof.circleimageview.CircleImageView
import life.league.challenge.kotlin.R
import life.league.challenge.kotlin.app.db.entities.User
import life.league.challenge.kotlin.app.ui.ViewModelFactory
import life.league.challenge.kotlin.app.ui.album.AlbumFragment


class ProfileActivity : AppCompatActivity(), View.OnClickListener {

    companion object {
        val BUNDLE_USERID = "BUNDLE_USERID"
    }

    private lateinit var viewModel: ProfileActivityViewModel

    private lateinit var toolbar: Toolbar
    private lateinit var avatar: CircleImageView
    private lateinit var name: TextView
    private lateinit var email: TextView
    private lateinit var phoneNumber: TextView
    private lateinit var webSite: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val userId = intent.extras?.getString(BUNDLE_USERID)

        setContentView(R.layout.activity_profile)

        toolbar = findViewById(R.id.toolbar)
        toolbar.title = "Profile"
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setDisplayShowHomeEnabled(true)

        avatar = findViewById(R.id.avatar)
        name = findViewById(R.id.name)
        email = findViewById(R.id.email)
        phoneNumber = findViewById(R.id.phonenumber)
        webSite = findViewById(R.id.website)

        email.setOnClickListener(this)
        phoneNumber.setOnClickListener(this)
        webSite.setOnClickListener(this)

        viewModel = ViewModelProvider(this, ViewModelFactory(this)).get(ProfileActivityViewModel::class.java)
        viewModel.viewState.observe(this, Observer { state -> updateViewState(state) })
        viewModel.loadUserProfile(userId)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> finish()
        }
        return super.onOptionsItemSelected(item)
    }

    private fun updateViewState(state: ProfileActivityViewState) {
        when (state) {
            ProfileActivityViewState.Loading -> {
            } //TODO("Add a loading indicator of sorts here")
            is ProfileActivityViewState.Error -> {
            } //TODO("show some sort of error screen here")
            is ProfileActivityViewState.Ready -> {
                val user: User = state.user
                Glide.with(this).load(state.user.avatar).into(avatar).waitForLayout()
                name.text = user.name
                email.text = user.email
                phoneNumber.text = user.phone
                webSite.text = user.website

                loadAlbumGrid(user.id)
            }
        }
    }

    private fun loadAlbumGrid(userId: String) {
        val frag: AlbumFragment = AlbumFragment.newInstance(userId)
        val transaction = supportFragmentManager.beginTransaction()
        transaction.add(R.id.album_container, frag, AlbumFragment.TAG)
        transaction.commit()
    }

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.email -> viewModel.sendEmail(this)
            R.id.phonenumber -> viewModel.startPhoneCall(this)
            R.id.website -> viewModel.openWebsite(this);
        }
    }
}
