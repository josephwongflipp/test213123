package life.league.challenge.kotlin.app.ui.album.models

data class UserAlbum(
        val id: String,
        val title: String
)