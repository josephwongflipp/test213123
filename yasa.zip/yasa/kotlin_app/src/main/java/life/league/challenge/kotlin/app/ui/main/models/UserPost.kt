package life.league.challenge.kotlin.app.ui.main.models

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

/**
 * ViewModel view-model only to be used by views.
 */
@Parcelize
data class UserPost(
        val userId: String?,
        val avatarUrl: String?,
        val username: String?,
        val title: String?,
        val description: String?
) : Parcelable