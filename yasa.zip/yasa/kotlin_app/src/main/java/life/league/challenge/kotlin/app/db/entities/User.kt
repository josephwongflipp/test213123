package life.league.challenge.kotlin.app.db.entities

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
class User(
        @PrimaryKey @ColumnInfo(name = "id") val id: String,
        @ColumnInfo(name = "avatar") val avatar: String,
        @ColumnInfo(name = "name") val name: String,
        @ColumnInfo(name = "username") val username: String,
        @ColumnInfo(name = "email") val email: String,
//        @ColumnInfo(name = "address") val address: Address,
        @ColumnInfo(name = "phone") val phone: String,
        @ColumnInfo(name = "website") val website: String
//        @ColumnInfo(name = "company") val company: Company
)

class Address(
        @ColumnInfo(name = "street") val street: String,
        @ColumnInfo(name = "suite") val suite: String,
        @ColumnInfo(name = "city") val city: String,
        @ColumnInfo(name = "zipcode") val zipcode: String,
        @ColumnInfo(name = "geo_lat") val geo_lat: String,
        @ColumnInfo(name = "geo_lng") val geo_lng: String
)


class Company(
        @ColumnInfo(name = "name") val name: String,
        @ColumnInfo(name = "catchPhrase") val catchPhrase: String,
        @ColumnInfo(name = "bs") val bs: String
)
