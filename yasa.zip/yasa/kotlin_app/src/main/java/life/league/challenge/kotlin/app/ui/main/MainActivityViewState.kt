package life.league.challenge.kotlin.app.ui.main

import life.league.challenge.kotlin.app.ui.main.models.UserPost

sealed class MainActivityViewState {
    object Loading : MainActivityViewState()
    class Error(val errorMsg: String?) : MainActivityViewState()
    class Ready(val userPosts: ArrayList<UserPost>) : MainActivityViewState()
}