package life.league.challenge.kotlin.app.ui.photo

import life.league.challenge.kotlin.app.ui.photo.models.UserAlbumPhoto

sealed class PhotoActivityViewState {
    object Loading : PhotoActivityViewState()
    class Error(val errorMsg: String?) : PhotoActivityViewState()
    class Ready(val userAlbumPhoto: UserAlbumPhoto) : PhotoActivityViewState()
}