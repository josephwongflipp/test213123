package life.league.challenge.kotlin.app.ui.photo.models

data class UserAlbumPhoto(
        val title: String?,
        val url: String?,
        val thumbnailUrl: String?
)