package life.league.challenge.kotlin.app.ui.profile

import life.league.challenge.kotlin.app.db.entities.User

sealed class ProfileActivityViewState {
    object Loading : ProfileActivityViewState()
    class Error(val errorMsg: String?) : ProfileActivityViewState()
    class Ready(val user: User) : ProfileActivityViewState()
}