package life.league.challenge.kotlin.app.ui.main

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import de.hdodenhof.circleimageview.CircleImageView
import life.league.challenge.kotlin.R
import life.league.challenge.kotlin.app.ui.main.models.UserPost


class PostAdapter(
        val userPosts: ArrayList<UserPost>,
        val clickListener: IPostAdapterClickListener)
    : RecyclerView.Adapter<PostAdapter.PostViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PostViewHolder {
        return PostViewHolder(LayoutInflater.from(parent.context).inflate(R.layout.row_post, parent, false))
    }

    override fun getItemCount(): Int {
        return userPosts.size
    }

    interface IPostAdapterClickListener {
        fun onPostClicked(userPost: UserPost)
    }

    override fun onBindViewHolder(holder: PostViewHolder, position: Int) {

        val userPost = userPosts[position]

        Glide.with(holder.avatar.context)
                .load(userPost.avatarUrl)
                .into(holder.avatar)
                .waitForLayout()

        holder.title.text = userPost.title
        holder.username.text = userPost.username
        holder.description.text = userPost.description
        holder.container.setOnClickListener { clickListener.onPostClicked(userPost) }
    }

    class PostViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val container: CardView = view.findViewById(R.id.container)
        val avatar: CircleImageView = view.findViewById(R.id.avatar)
        val title: TextView = view.findViewById(R.id.title)
        val username: TextView = view.findViewById(R.id.username)
        val description: TextView = view.findViewById(R.id.description)
    }
}
