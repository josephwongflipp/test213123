package life.league.challenge.kotlin.app.db.daos

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import life.league.challenge.kotlin.app.db.entities.Post

@Dao
interface PostDao {
    @Query("SELECT * from posts")
    suspend fun getPosts(): List<Post>?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPosts(posts: List<Post>)

    @Query("DELETE FROM posts")
    suspend fun truncate()
}
