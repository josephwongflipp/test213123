package life.league.challenge.kotlin.app.ui.album

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import life.league.challenge.kotlin.app.injectables.AppRepository
import life.league.challenge.kotlin.app.ui.Status

class AlbumFragmentViewModel(
        private val repository: AppRepository,
        private val dispatcher: CoroutineDispatcher = Dispatchers.IO) : ViewModel() {

    private val _viewState: MutableLiveData<AlbumFragmentViewState> = MutableLiveData()
    val viewState: LiveData<AlbumFragmentViewState> get() = _viewState

    fun loadAlbums(userId: String) {
        _viewState.postValue(AlbumFragmentViewState.Loading)
        viewModelScope.launch {
            withContext(dispatcher) {
                val wrapper = repository.getAlbums(userId)
                when (wrapper.status) {
                    Status.SUCCESS -> _viewState.postValue(AlbumFragmentViewState.Ready(wrapper.data!!))
                    Status.ERROR -> _viewState.postValue(AlbumFragmentViewState.Error(wrapper.errorMsg))
                }
            }
        }
    }
}
