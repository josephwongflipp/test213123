package life.league.challenge.kotlin.app.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import life.league.challenge.kotlin.app.db.daos.AlbumDao
import life.league.challenge.kotlin.app.db.daos.PhotoDao
import life.league.challenge.kotlin.app.db.daos.PostDao
import life.league.challenge.kotlin.app.db.daos.UserDao
import life.league.challenge.kotlin.app.db.entities.Album
import life.league.challenge.kotlin.app.db.entities.Photo
import life.league.challenge.kotlin.app.db.entities.Post
import life.league.challenge.kotlin.app.db.entities.User

@Database(
        entities = [User::class, Post::class, Album::class, Photo::class],
        version = 1,
        exportSchema = false
)

/**
 * Core database implementation using Room DB.
 */
abstract class AppDatabase : RoomDatabase() {
    abstract fun userDao(): UserDao
    abstract fun postDao(): PostDao
    abstract fun albumDao(): AlbumDao
    abstract fun photoDao(): PhotoDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            val tempInstance = INSTANCE
            if (tempInstance != null) {
                return tempInstance
            }
            synchronized(this) {
                val instance = Room.databaseBuilder(
                        context.applicationContext,
                        AppDatabase::class.java,
                        "appdb"
                ).build()
                INSTANCE = instance
                return instance
            }
        }
    }
}
