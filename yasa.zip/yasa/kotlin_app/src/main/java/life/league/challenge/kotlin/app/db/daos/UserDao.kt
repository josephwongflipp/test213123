package life.league.challenge.kotlin.app.db.daos

import android.util.SparseArray
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import life.league.challenge.kotlin.app.db.entities.User

@Dao
interface UserDao {
    @Query("SELECT * from users")
    suspend fun getUsers(): List<User>?

    @Query("SELECT * from users WHERE id IN (:userIds)")
    suspend fun getUsersById(userIds: String): List<User>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUsers(users: List<User>)

    @Query("DELETE FROM users")
    suspend fun truncate()
}