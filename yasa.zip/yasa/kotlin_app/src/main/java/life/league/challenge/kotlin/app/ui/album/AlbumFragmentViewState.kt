package life.league.challenge.kotlin.app.ui.album

import life.league.challenge.kotlin.app.ui.album.models.UserAlbum

sealed class AlbumFragmentViewState {
    object Loading : AlbumFragmentViewState()
    class Error(val errorMsg: String?) : AlbumFragmentViewState()
    class Ready(val albums: ArrayList<UserAlbum>) : AlbumFragmentViewState()
}