package life.league.challenge.kotlin.app.ui

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import life.league.challenge.kotlin.api.Service
import life.league.challenge.kotlin.app.db.AppDatabase
import life.league.challenge.kotlin.app.injectables.AppRepository
import life.league.challenge.kotlin.app.injectables.DeviceHelper
import life.league.challenge.kotlin.app.injectables.SharedPrefHelper
import life.league.challenge.kotlin.app.ui.album.AlbumFragmentViewModel
import life.league.challenge.kotlin.app.ui.main.MainActivityViewModel
import life.league.challenge.kotlin.app.ui.photo.PhotoActivityViewModel
import life.league.challenge.kotlin.app.ui.profile.ProfileActivityViewModel
import java.lang.Exception

@Suppress("UNCHECKED_CAST")
class ViewModelFactory(context: Context) : ViewModelProvider.Factory {
    val deviceHelper: DeviceHelper = DeviceHelper(context)
    val service: Service = Service()
    val sharedPrefHelper: SharedPrefHelper = SharedPrefHelper(context)
    val repository: AppRepository = AppRepository(deviceHelper, sharedPrefHelper, service, AppDatabase.getDatabase(context))

    override fun <T : ViewModel?> create(modelClass: Class<T>): T {
        when (modelClass) {
            MainActivityViewModel::class.java -> {
                return MainActivityViewModel(repository) as T
            }
            ProfileActivityViewModel::class.java -> {
                return ProfileActivityViewModel(repository) as T
            }
            AlbumFragmentViewModel::class.java -> {
                return AlbumFragmentViewModel(repository) as T
            }
            PhotoActivityViewModel::class.java -> {
                return PhotoActivityViewModel(repository) as T
            }
            else -> throw Exception("ERROR: Invalid viewmodel selected!")
        }
    }
}