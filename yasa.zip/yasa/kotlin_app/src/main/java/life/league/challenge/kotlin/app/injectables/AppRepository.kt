package life.league.challenge.kotlin.app.injectables

import life.league.challenge.kotlin.api.Service
import life.league.challenge.kotlin.app.db.AppDatabase
import life.league.challenge.kotlin.app.db.entities.Album
import life.league.challenge.kotlin.app.db.entities.Photo
import life.league.challenge.kotlin.app.db.entities.Post
import life.league.challenge.kotlin.app.db.entities.User
import life.league.challenge.kotlin.app.ui.DataWrapper
import life.league.challenge.kotlin.app.ui.Status
import life.league.challenge.kotlin.app.ui.album.models.UserAlbum
import life.league.challenge.kotlin.app.ui.main.models.UserPost
import life.league.challenge.kotlin.app.ui.photo.models.UserAlbumPhoto
import life.league.challenge.kotlin.model.Account

/**
 * Universal repository for retrieving data to be consumed by ViewModels.
 */
class AppRepository(
        private val deviceHelper: DeviceHelper,
        private val sharedPrefHelper: SharedPrefHelper,
        private val apiService: Service,
        private val database: AppDatabase) {

    /**
     * Retrieves the apiKey based on the user's username/password
     */
    suspend fun login(username: String, password: String): DataWrapper<Account> {
        // NOTE: simplifying authentication flow, if you've logged in before just re-use the same apiKey.
        if (isCachedApiKeyValid()) {
            return DataWrapper(Status.SUCCESS, Account(sharedPrefHelper.getApiKey()), null)
        }
        if (deviceHelper.hasNetwork()) {
            val account : Account? = apiService.login(username, password)
            if (account?.apiKey == null) {
                return DataWrapper(Status.ERROR, null, "ERROR: Invalid accounts/apiKey response.")
            }
            sharedPrefHelper.saveApiKey(account.apiKey)
            return DataWrapper(Status.SUCCESS, account, null)
        }

        return DataWrapper(Status.ERROR, null, "ERROR: Cannot login without network connectivity")
    }

    /**
     * Retrieves all users and their posts.
     *
     * This function takes a best effort approach. If the userfails to get fresh data
     * from the API or is offline we show the cached data.
     */
    suspend fun getUserPosts() : DataWrapper<ArrayList<UserPost>> {
        if (!isCachedApiKeyValid()) {
            return DataWrapper(Status.ERROR, null, "ERROR: apiKey is invalid, please login again.")
        }
        val apiKey = sharedPrefHelper.getApiKey()!!

        // If we have network connection, load fresh from the web.
        if (deviceHelper.hasNetwork()) {
            val apiUsers: List<User>? = apiService.getUsers(apiKey)
            val apiPosts: List<Post>? = apiService.getPosts(apiKey)

            // If we managed to fetch users and posts successfully, truncate and insert to our DB
            if (!apiUsers.isNullOrEmpty() && !apiPosts.isNullOrEmpty()) {

                // Truncate the database, important to truncate photos as well.
                database.userDao().truncate()
                database.postDao().truncate()
                database.albumDao().truncate()
                database.photoDao().truncate()
                database.userDao().insertUsers(apiUsers)
                database.postDao().insertPosts(apiPosts)

                // We already have the data at this point, no point going trough our DB again.
                // Munge the data and return a collection of UserPosts
                return DataWrapper(Status.SUCCESS, getUserPosts(ArrayList(apiUsers), ArrayList(apiPosts)), null)
            }
        }

        // Otherwise, attempt to load data from DB instead.
        val dbUsers: List<User>? = database.userDao().getUsers()
        val dbPosts: List<Post>? = database.postDao().getPosts()

        if (!dbUsers.isNullOrEmpty() && !dbPosts.isNullOrEmpty()) {
            return DataWrapper(Status.SUCCESS, getUserPosts(ArrayList(dbUsers), ArrayList(dbPosts)), null)
        }

        // At this point, even with a valid apiKey we couldn't get the data, return an error.
        return DataWrapper(Status.ERROR, null, "ERROR: No valid user posts can be shown.")
    }

    /**
     * Retrieve the record of one user from our DB.
     */
    suspend fun getUser(userId: String) : DataWrapper<User> {
        val user = database.userDao().getUsersById(userId)
        if (user.isNullOrEmpty()) {
            return DataWrapper(Status.ERROR, null, "Unable to find user in our database")
        }
        return DataWrapper(Status.SUCCESS, user[0], null)
    }

    /**
     * Retrieve the albums given an userId. Best effort strategy.
     */
    suspend fun getAlbums(userId: String) : DataWrapper<ArrayList<UserAlbum>> {
        if (!isCachedApiKeyValid()) {
            return DataWrapper(Status.ERROR, null, "ERROR: apiKey is invalid, please login again.")
        }
        val apiKey = sharedPrefHelper.getApiKey()!!

        // Attempt to grab albums from api, if that fails we attempt to grab it from the DB
        var albums: List<Album>? = null
        if (deviceHelper.hasNetwork()) {
            albums = apiService.getAlbums(apiKey, userId)
            if (albums != null) {
                database.albumDao().insertAlbums(albums)
            }
        }
        if (albums == null) {
            albums = database.albumDao().getAlbumsByUserIds(userId)
        }
        if (albums.isNullOrEmpty()) {
            if (!deviceHelper.hasNetwork()) {
                return DataWrapper(Status.ERROR, null, "No internet connection, cannot load album data")
            }
            return DataWrapper(Status.ERROR, null, "Unable to load album from api/db (likely /albums returning 5XX)")
        }

        val result: ArrayList<UserAlbum> = ArrayList()
        albums.forEach { album ->
            result.add(UserAlbum(album.id, album.title))
        }

        return DataWrapper(Status.SUCCESS, result, null)
    }

    /**
     * Retrieves photos given an albumId. Best effort strategy.
     */
    suspend fun getPhotos(albumId: String) : DataWrapper<ArrayList<UserAlbumPhoto>> {
        if (!isCachedApiKeyValid()) {
            return DataWrapper(Status.ERROR, null, "ERROR: apiKey is invalid, please login again.")
        }
        val apiKey = sharedPrefHelper.getApiKey()!!

        // Attempt to grab albums from api, if that fails we attempt to grab it from the DB
        var photos: List<Photo>? = null
        if (deviceHelper.hasNetwork()) {
            photos = apiService.getPhotos(apiKey, albumId)
            if (photos != null) {
                database.photoDao().insertPhotos(photos)
            }
        }
        if (photos == null) {
            photos = database.photoDao().getPhotosByAlbumId(albumId)
        }
        if (photos.isNullOrEmpty()) {
            if (!deviceHelper.hasNetwork()) {
                return DataWrapper(Status.ERROR, null, "No internet connection, cannot load photo data")
            }
            return DataWrapper(Status.ERROR, null, "Unable to load photo from api/db (likely /photos returning 5XX)")
        }

        val result: ArrayList<UserAlbumPhoto> = ArrayList()
        photos.forEach { photo ->
            result.add(UserAlbumPhoto(photo.title, photo.url, photo.thumbnailUrl))
        }

        return DataWrapper(Status.SUCCESS, result, null)
    }

    /**
     * Munges two sets of data, Users and Posts, and returns a collection of UserPosts
     * with user data associated to posts for view display.
     */
    private fun getUserPosts(users: ArrayList<User>?, posts: ArrayList<Post>?): ArrayList<UserPost>? {
        val userMap: HashMap<String, User> = HashMap()
        users?.forEach { user ->
            userMap[user.id] = user
        }

        val userPosts: ArrayList<UserPost> = ArrayList()
        posts?.forEach { post ->
            val user = userMap.get(post.userId)
            userPosts.add(UserPost(
                    user?.id,
                    user?.avatar,
                    user?.username,
                    post.title,
                    post.body
            ))
        }
        return userPosts
    }

    /**
     * Checks to see if our cached apiKey is valid.
     *
     * NOTE: For now, a valid apiKey is a non-null/non-empty key. Typically I would
     *       check validity by calling the web service here, but for now we just care
     *       if it exists.
     */
    private fun isCachedApiKeyValid(): Boolean {
        val apiKey = sharedPrefHelper.getApiKey()
        return !apiKey.isNullOrEmpty()
    }
}