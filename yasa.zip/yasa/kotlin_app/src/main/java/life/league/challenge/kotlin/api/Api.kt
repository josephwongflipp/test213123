package life.league.challenge.kotlin.api

import android.util.SparseArray
import life.league.challenge.kotlin.app.db.entities.Album
import life.league.challenge.kotlin.app.db.entities.Photo
import life.league.challenge.kotlin.app.db.entities.Post
import life.league.challenge.kotlin.app.db.entities.User
import life.league.challenge.kotlin.model.Account
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.Query

interface Api {

    @GET("login")
    fun login(@Header("Authorization") credentials: String?): Call<Account>

    @GET("users")
    fun users(@Header("x-access-token") apiKey: String? ): Call<List<User>>

    @GET("posts")
    fun posts(@Header("x-access-token") apiKey: String? ): Call<List<Post>>

    @GET("posts")
    fun albums(
            @Header("x-access-token") apiKey: String?,
            @Query("userId") userId: String?
    ): Call<List<Album>>

    @GET("photos")
    fun photos(
            @Header("x-access-token") apiKey: String?,
            @Query("albumId") albumId: String?
    ): Call<List<Photo>>

}
