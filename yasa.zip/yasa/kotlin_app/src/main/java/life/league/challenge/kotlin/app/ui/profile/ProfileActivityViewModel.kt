package life.league.challenge.kotlin.app.ui.profile

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import androidx.core.app.ActivityCompat
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import life.league.challenge.kotlin.app.db.entities.User
import life.league.challenge.kotlin.app.injectables.AppRepository
import life.league.challenge.kotlin.app.ui.Status


class ProfileActivityViewModel(
        private val appRepository: AppRepository) : ViewModel() {

    private val _viewState: MutableLiveData<ProfileActivityViewState> = MutableLiveData()
    val viewState: LiveData<ProfileActivityViewState> get() = _viewState
    var user: User? = null

    fun loadUserProfile(userId: String?) {
        if (userId.isNullOrEmpty()) {
            _viewState.postValue(ProfileActivityViewState.Error("Invalid userId passed in."))
            return;
        }
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                val wrapper = appRepository.getUser(userId)
                when (wrapper.status) {
                    Status.SUCCESS -> {
                        user = wrapper.data
                        val userRef = wrapper.data
                        if (userRef == null) {
                            _viewState.postValue(ProfileActivityViewState.Error("Server call was successful but user data was null"))
                        } else {
                            _viewState.postValue(ProfileActivityViewState.Ready(userRef))
                        }
                    }
                    Status.ERROR -> _viewState.postValue(ProfileActivityViewState.Error("Unable to load user data"))
                }
            }
        }
    }

    fun sendEmail(activity: Activity) {
        user?.let { it ->
            val emailIntent = Intent(Intent.ACTION_SENDTO, Uri.fromParts("mailto", it.email, null))
            emailIntent.putExtra(Intent.EXTRA_SUBJECT, "Hello from League's YASA")
            emailIntent.putExtra(Intent.EXTRA_TEXT, "This is some body text -Joseph")
            activity.startActivity(Intent.createChooser(emailIntent, "Send email..."))
        }
    }

    fun startPhoneCall(activity: Activity) {
        user?.let { it ->
            val intent = Intent(Intent.ACTION_CALL, Uri.parse("tel:" + it.phone))
            if (ActivityCompat.checkSelfPermission(activity, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(activity, arrayOf(Manifest.permission.CALL_PHONE), 1337)
                return
            }
            activity.startActivity(intent)
        }
    }

    fun openWebsite(activity: Activity) {
        user?.let { it ->
            val intent = Intent(Intent.ACTION_VIEW)
            var cleanedWebsite = it.website
            if (!cleanedWebsite.contains("http", true)) {
                // Hacky way of adding a scheme to the Uri to prevent Android crashes.
                cleanedWebsite = "https://$cleanedWebsite"
            }
            intent.data = Uri.parse(cleanedWebsite)
            activity.startActivity(intent)
        }
    }
}
