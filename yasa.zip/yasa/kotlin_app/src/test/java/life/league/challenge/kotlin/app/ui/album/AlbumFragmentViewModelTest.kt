package life.league.challenge.kotlin.app.ui.album

import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import androidx.lifecycle.Observer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.test.TestCoroutineDispatcher
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runBlockingTest
import kotlinx.coroutines.test.setMain
import life.league.challenge.kotlin.app.injectables.AppRepository
import life.league.challenge.kotlin.app.ui.DataWrapper
import life.league.challenge.kotlin.app.ui.Status
import life.league.challenge.kotlin.app.ui.album.models.UserAlbum
import org.junit.*
import org.junit.runner.RunWith
import org.mockito.Mockito
import org.mockito.Mockito.`when`
import org.mockito.junit.MockitoJUnitRunner

@RunWith(MockitoJUnitRunner::class)
class AlbumFragmentViewModelTest {

    @get:Rule
    var instantTaskExecutorRule = InstantTaskExecutorRule()

    companion object {
        private val TEST_USERID = "500"
    }

    private val testDispatcher = TestCoroutineDispatcher()

    var mockRepository: AppRepository = Mockito.mock(AppRepository::class.java)

    @Before
    fun setUp() {
        Dispatchers.setMain(testDispatcher)
    }

    @After
    fun tearDown() {
        Dispatchers.resetMain()
    }

    /**
     * Happy path unit test
     */
    @Test
    fun loadAlbums() {
        testDispatcher.runBlockingTest {
            // valid album response
            val albums = ArrayList<UserAlbum>()
            albums.add(UserAlbum("123", "summer trip"))

            // mocking the repo
            `when`(mockRepository.getAlbums(TEST_USERID)).thenReturn(DataWrapper(Status.SUCCESS, albums, null))

            val viewModel = AlbumFragmentViewModel(mockRepository, testDispatcher)
            viewModel.loadAlbums(TEST_USERID)

            Assert.assertTrue(
                    "Successful login should display READY status but got ${viewModel.viewState.value} instead",
                    viewModel.viewState.value is AlbumFragmentViewState.Ready)
        }

    }
}