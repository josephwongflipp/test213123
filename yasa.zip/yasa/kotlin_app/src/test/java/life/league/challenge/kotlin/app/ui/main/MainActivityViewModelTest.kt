package life.league.challenge.kotlin.app.ui.main

import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.test.TestCoroutineDispatcher
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runBlockingTest
import kotlinx.coroutines.test.setMain
import life.league.challenge.kotlin.app.injectables.AppRepository
import life.league.challenge.kotlin.app.injectables.SharedPrefHelper
import life.league.challenge.kotlin.app.ui.DataWrapper
import life.league.challenge.kotlin.app.ui.Status
import life.league.challenge.kotlin.app.ui.main.models.UserPost
import life.league.challenge.kotlin.model.Account
import org.junit.*
import org.junit.runner.RunWith
import org.mockito.ArgumentMatchers.anyString
import org.mockito.Mockito.`when`
import org.mockito.Mockito.mock
import org.mockito.junit.MockitoJUnitRunner

/**
 * Simple unit tests for checking against the view state of the viewmodels.
 */
@RunWith(MockitoJUnitRunner::class)
class MainActivityViewModelTest {

    @get:Rule
    var instantTaskExecutorRule = InstantTaskExecutorRule()

    companion object {
        private val TEST_APIKEY = "abc-123-efg-456"
    }
    private val testDispatcher = TestCoroutineDispatcher()

    var mockRepository: AppRepository = mock(AppRepository::class.java)


    @Before
    fun setUp() {
        Dispatchers.setMain(testDispatcher)
    }

    @After
    fun tearDown() {
        Dispatchers.resetMain()
    }

    /**
     * When the repository returns successfully from logging in.
     */
    @Test
    fun loginAndFetchPosts_viewStateReady() {
        testDispatcher.runBlockingTest {
            val account = Account(TEST_APIKEY);
            val userPosts = ArrayList<UserPost>()
            userPosts.add(UserPost("123","https://a.com/b.gif", "username", "title", "desc"))

            `when`(mockRepository.login(anyString(), anyString()))
                    .thenReturn(DataWrapper(Status.SUCCESS, account, null))

            `when`(mockRepository.getUserPosts())
                    .thenReturn(DataWrapper(Status.SUCCESS, userPosts, null))

            val viewModel = MainActivityViewModel(mockRepository, testDispatcher)
            viewModel.loginAndFetchPosts("test", "password")

            Assert.assertTrue(
                    "Successful login should display READY status but got ${viewModel.viewState.value} instead",
                    viewModel.viewState.value is MainActivityViewState.Ready)
        }
    }

    /**
     * When the repository returns an error at the login stage
     */
    @Test
    fun loginAndFetchPosts_viewStateError_login() {
        testDispatcher.runBlockingTest {
            `when`(mockRepository.login(anyString(), anyString()))
                    .thenReturn(DataWrapper(Status.ERROR, null, null))

            val viewModel = MainActivityViewModel(mockRepository, testDispatcher)
            viewModel.loginAndFetchPosts("test", "password")

            Assert.assertTrue(
                    "Successful login should display ERROR status but got ${viewModel.viewState.value} instead",
                    viewModel.viewState.value is MainActivityViewState.Error)
        }
    }
}
