package life.league.challenge.kotlin.app.injectables

import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import kotlinx.coroutines.asExecutor
import kotlinx.coroutines.test.TestCoroutineScope
import kotlinx.coroutines.test.runBlockingTest
import life.league.challenge.kotlin.api.Service
import life.league.challenge.kotlin.app.db.AppDatabase
import life.league.challenge.kotlin.app.db.entities.Post
import life.league.challenge.kotlin.app.db.entities.User
import life.league.challenge.kotlin.app.ui.Status
import life.league.challenge.kotlin.helpers.AppTest
import org.junit.After
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.Mockito
import org.mockito.Mockito.`when`

/**
 * Testing the repository
 *
 * NOTE: I'm cheating a bit by bringing in AndroidJUnit4 and context for our unit tests,
 *       because I'm passing in AppDatabase. If I had more time I'd abstract out another
 *       DB layer to allow for better mocking.
 */
@RunWith(AndroidJUnit4::class)
class AppRepositoryTest: AppTest() {
    private lateinit var mockDeviceHelper: DeviceHelper
    private lateinit var mockSharedPrefHelper: SharedPrefHelper
    private lateinit var mockApiService: Service
    private lateinit var mockDatabase: AppDatabase

    @Before
    override fun setUp() {
        super.setUp()
        mockDeviceHelper = Mockito.mock(DeviceHelper::class.java)
        mockSharedPrefHelper = Mockito.mock(SharedPrefHelper::class.java)
        mockApiService = Mockito.mock(Service::class.java)
        mockDatabase = Room.inMemoryDatabaseBuilder(
                ApplicationProvider.getApplicationContext(),
                AppDatabase::class.java)
                    .setTransactionExecutor(testDispatcher.asExecutor())
                    .setQueryExecutor(testDispatcher.asExecutor())
                    .allowMainThreadQueries() // NOTE: struggling on figuring out why this wont respect runBlockingTest
                    .build()
    }

    @After
    override fun tearDown() {
        super.tearDown()
    }

    @Test
    fun getUserPosts_noInternet() {
        testScope.runBlockingTest {
            val repository = AppRepository(
                    mockDeviceHelper,
                    mockSharedPrefHelper,
                    mockApiService,
                    mockDatabase)

            `when`(mockSharedPrefHelper.getApiKey()).thenReturn(null)
            `when`(mockDeviceHelper.hasNetwork()).thenReturn(false)

            assertTrue("getUserPosts should return a wrapped error for new users without internet",
                    repository.getUserPosts().status == Status.ERROR)
        }
    }

    @Test
    fun getUserPosts_successfulResponseFromApi() {
        runBlockingTest {
            val testApiKey = "API_KEY"
            val testUsers: ArrayList<User> = ArrayList()
            testUsers.add(User("123", "someUrl", "sadf", "sadf", "sadfsaf", "asfd", "sadf"))
            val testPosts: ArrayList<Post> = ArrayList()
            testPosts.add(Post("555", "123", "sadf", "sadf"))

            val repository = AppRepository(
                    mockDeviceHelper,
                    mockSharedPrefHelper,
                    mockApiService,
                    mockDatabase)

            `when`(mockSharedPrefHelper.getApiKey()).thenReturn(testApiKey)
            `when`(mockDeviceHelper.hasNetwork()).thenReturn(true)
            `when`(mockApiService.getUsers(testApiKey)).thenReturn(testUsers)
            `when`(mockApiService.getPosts(testApiKey)).thenReturn(testPosts)

            assertTrue("getUserPosts should return a success for new users with internet",
                    repository.getUserPosts().status == Status.SUCCESS)
        }
    }
}
